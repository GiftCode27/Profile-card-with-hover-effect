# Profile card with  hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gift27/pen/bGvpZXJ](https://codepen.io/Gift27/pen/bGvpZXJ).

